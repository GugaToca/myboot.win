<#
    executar.ps1 - Executa uma acao demorada em janela propria.
    Chamado pela interface grafica. Nao precisa ser aberto direto.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateSet('importar-midia','baixar-midia','preparar-ambiente','testar-boot','formatar','desarmar','limpar-staging')]
    [string]$Acao,

    [string]$Caminho,      # origem da midia (.zip / .iso / pasta)
    [string]$MidiaNome,    # nome da midia ja importada
    [string]$UrlSite,      # endereco do site (para baixar da internet)
    [string]$ImagemId,     # id da imagem no catalogo
    [int]   $Indice = 1    # edicao dentro da imagem
)

$ErrorActionPreference = 'Stop'
$lib = Join-Path $PSScriptRoot 'lib'
. (Join-Path $lib 'comum.ps1')
. (Join-Path $lib 'winpe.ps1')
. (Join-Path $lib 'boot.ps1')
. (Join-Path $lib 'disco.ps1')
. (Join-Path $lib 'midia.ps1')

$Host.UI.RawUI.WindowTitle = "Sistema de Formatacao - $Acao"

function Pausar {
    Write-Host ''
    Write-Host '  Pressione ENTER para fechar esta janela.' -ForegroundColor Cyan
    [void](Read-Host)
}
function Cabecalho($t) {
    Clear-Host
    Write-Host ''
    Write-Host ('  ' + ('=' * 64)) -ForegroundColor Cyan
    Write-Host "   $t" -ForegroundColor Cyan
    Write-Host ('  ' + ('=' * 64)) -ForegroundColor Cyan
    Write-Host ''
}

try {
switch ($Acao) {

# =================================================================
'importar-midia' {
    Cabecalho 'IMPORTAR A IMAGEM DO WINDOWS'
    Write-Host '  Isto copia a sua midia para dentro do sistema.' -ForegroundColor Gray
    Write-Host '  Arquivos grandes levam de 10 a 40 minutos.' -ForegroundColor Yellow
    Write-Host ''

    if (-not $Caminho) { throw 'Nenhum arquivo informado.' }

    $m = Importar-Midia -Origem $Caminho
    if (-not $m) { throw 'Nao foi possivel importar esta midia.' }

    Write-Host ''
    Write-Host '  IMAGEM IMPORTADA COM SUCESSO' -ForegroundColor Green
    Write-Host ''
    Write-Host "  Nome ....: $($m.Nome)" -ForegroundColor White
    Write-Host "  Arquivo .: $($m.ImagemNome)" -ForegroundColor White
    if ($m.Dividida) { Write-Host "  Formato .: dividida em $($m.Partes) partes" -ForegroundColor White }
    foreach ($e in $m.Edicoes) { Write-Host "  Edicao ..: [$($e.Indice)] $($e.Nome)" -ForegroundColor White }
    Write-Host ''
    Write-Host '  Proximo passo: botao "Preparar ambiente" na tela principal.' -ForegroundColor Cyan
    Pausar
}

# =================================================================
'baixar-midia' {
    Cabecalho 'BAIXAR IMAGEM DA INTERNET'

    $cat = Obter-CatalogoWeb -UrlSite $UrlSite
    if (-not $cat) { throw 'Nao consegui ler o catalogo do site.' }

    if (-not $ImagemId) {
        # Sem id informado: mostra a lista e deixa escolher
        $imgs = @($cat.imagens)
        if ($imgs.Count -eq 0) { throw 'O catalogo esta vazio.' }

        Write-Host '  Imagens publicadas:' -ForegroundColor White
        Write-Host ''
        for ($k = 0; $k -lt $imgs.Count; $k++) {
            $tam = ''
            if ($imgs[$k].tamanhoBytes) { $tam = '  -  ' + (Formatar-Tamanho $imgs[$k].tamanhoBytes) }
            Write-Host ("   [{0}] {1}{2}" -f ($k+1), $imgs[$k].nome, $tam) -ForegroundColor Gray
        }
        Write-Host ''
        $esc = Read-Host '  Numero da imagem'
        $idx = 0
        if (-not [int]::TryParse($esc, [ref]$idx) -or $idx -lt 1 -or $idx -gt $imgs.Count) {
            throw 'Opcao invalida.'
        }
        $ImagemId = $imgs[$idx-1].id
    }

    Write-Host ''
    Write-Host '  O download e grande. Pode levar horas dependendo da internet.' -ForegroundColor Yellow
    Write-Host '  Se cair a conexao, e so rodar de novo: ele retoma de onde parou.' -ForegroundColor Gray
    Write-Host ''

    $m = Importar-MidiaDaWeb -Catalogo $cat -ImagemId $ImagemId
    if (-not $m) { throw 'Nao foi possivel baixar esta imagem.' }

    Write-Host ''
    Write-Host '  IMAGEM PRONTA PARA USO' -ForegroundColor Green
    Write-Host ''
    Write-Host "  $($m.Rotulo)" -ForegroundColor White
    foreach ($e in $m.Edicoes) { Write-Host "  Edicao: [$($e.Indice)] $($e.Nome)" -ForegroundColor White }
    Write-Host ''
    Write-Host '  Proximo passo: botao "Preparar ambiente".' -ForegroundColor Cyan
    Pausar
}

# =================================================================
'preparar-ambiente' {
    Cabecalho 'PREPARAR O AMBIENTE DE FORMATACAO'

    # ---------------------------------------------------------------
    # Caminho rapido: o servidor ja mandou o ambiente pronto junto com
    # a imagem. Nesse caso e so colocar no lugar - segundos em vez de
    # 5 a 15 minutos montando e desmontando o WIM em cada maquina.
    # ---------------------------------------------------------------
    $pronto = $null
    foreach ($md in (Listar-Midias)) {
        if ($md.WinPEProntoWim -and (Test-Path $md.WinPEProntoWim)) { $pronto = $md; break }
    }

    if ($pronto) {
        Write-Host '  O ambiente ja veio pronto do servidor.' -ForegroundColor Green
        Write-Host '  Nao precisa montar nada aqui: leva segundos.' -ForegroundColor Gray
        Write-Host ''

        $ok = Instalar-WinPEPronto -ArquivoWim $pronto.WinPEProntoWim -ArquivoSdi $pronto.WinPEProntoSdi

        Write-Host ''
        if ($ok) { Write-Host '  PRONTO. O ambiente foi instalado.' -ForegroundColor Green }
        else {
            Write-Host '  Nao consegui usar o ambiente pronto. Vou montar aqui mesmo.' -ForegroundColor Yellow
            Write-Host ''
        }
        if ($ok) { Pausar; break }
    }

    Write-Host '  Isto leva de 5 a 15 minutos e so precisa ser feito uma vez.' -ForegroundColor Yellow
    Write-Host ''

    # Prefere o boot.wim da propria midia (nao precisa do Windows ADK)
    $bootWim = $null
    foreach ($md in (Listar-Midias)) {
        if ($md.BootWim -and (Test-Path $md.BootWim)) { $bootWim = $md.BootWim; break }
    }

    $ok = $false
    if ($bootWim) {
        Write-Host '  Usando o ambiente de boot da sua propria midia.' -ForegroundColor Green
        Write-Host '  (o Windows ADK nao e necessario)' -ForegroundColor Gray
        Write-Host ''
        $ok = Construir-WinPE-DaMidia -BootWimOrigem $bootWim
    } else {
        Write-Host '  Nenhuma midia importada com boot.wim.' -ForegroundColor Yellow
        Write-Host '  Tentando usar o Windows ADK...' -ForegroundColor Yellow
        Write-Host ''
        $ok = Construir-WinPE
    }

    Write-Host ''
    if ($ok) { Write-Host '  PRONTO. O ambiente foi criado com sucesso.' -ForegroundColor Green }
    else {
        Write-Host '  FALHOU. Veja as mensagens acima.' -ForegroundColor Red
        Write-Host "  Registro completo: $Global:LOG_ATUAL" -ForegroundColor Gray
    }
    Pausar
}

# =================================================================
'testar-boot' {
    Cabecalho 'TESTE DE INICIALIZACAO (MODO SEGURO)'
    Write-Host '  Este teste NAO formata nada.' -ForegroundColor Green
    Write-Host '  O computador reinicia, carrega o ambiente, mostra um' -ForegroundColor Gray
    Write-Host '  diagnostico e volta sozinho para o Windows.' -ForegroundColor Gray
    Write-Host ''

    if (-not (Armar-Boot -Tarefa @{ MODO='TESTE'; NOME='(somente teste)' } -Destino 'C:\DEPLOY')) {
        Write-Host ''
        Write-Host '  Nao foi possivel preparar o teste.' -ForegroundColor Red
        Pausar; break
    }

    Write-Host ''
    Write-Host '  Tudo pronto.' -ForegroundColor Green
    Write-Host ''
    Write-Host '  IMPORTANTE: fique olhando a tela apos o reinicio.' -ForegroundColor Yellow
    Write-Host ''
    $r = Read-Host '  Reiniciar agora? (S/N)'
    if ($r -match '^[SsYy]') {
        & shutdown.exe /r /t 20 /c 'Sistema de Formatacao - teste'
        Write-Host '  Reiniciando em 20 segundos... (cancelar: shutdown /a)' -ForegroundColor Cyan
        Start-Sleep -Seconds 4
    } else {
        Write-Host '  Cancelado. O teste segue agendado para o proximo reinicio.' -ForegroundColor Yellow
        Write-Host '  Use "Cancelar / Reverter" para desarmar.' -ForegroundColor Gray
        Pausar
    }
}

# =================================================================
'formatar' {
    Cabecalho 'FORMATACAO REAL'
    Write-Host '  ATENCAO: este processo APAGA TODOS OS DADOS deste computador.' -ForegroundColor Red
    Write-Host ''

    $md = (Listar-Midias) | Where-Object { $_.Nome -eq $MidiaNome } | Select-Object -First 1
    if (-not $md) { throw "Imagem '$MidiaNome' nao encontrada." }

    $ed = $md.Edicoes | Where-Object { $_.Indice -eq $Indice } | Select-Object -First 1
    $nomeEd = if ($ed) { $ed.Nome } else { $md.ImagemNome }

    Write-Host "  Imagem ....: $($md.Nome)" -ForegroundColor White
    Write-Host "  Edicao ....: [$Indice] $nomeEd" -ForegroundColor White
    Write-Host ("  Tamanho ...: {0}" -f (Formatar-Tamanho $md.Tamanho)) -ForegroundColor White
    Write-Host ''

    $cs = Get-CimInstance Win32_ComputerSystem
    Write-Host "  Equipamento: $($cs.Manufacturer) $($cs.Model)" -ForegroundColor White
    Write-Host "  Nome atual : $env:COMPUTERNAME" -ForegroundColor White
    Write-Host ''

    # ------------------------------------------------ Confirmacoes
    Write-Host "  Para confirmar, digite o nome do computador: $env:COMPUTERNAME" -ForegroundColor Yellow
    $c1 = Read-Host '  Nome'
    if ($c1 -ne $env:COMPUTERNAME) { Write-Host ''; Write-Host '  Nome incorreto. Cancelado.' -ForegroundColor Red; Pausar; break }

    Write-Host ''
    $c2 = Read-Host '  O backup dos dados do cliente ja foi feito? (digite SIM)'
    if ($c2 -ne 'SIM') { Write-Host ''; Write-Host '  Cancelado. Faca o backup primeiro.' -ForegroundColor Red; Pausar; break }

    # ------------------------------------------------ Identificar particoes
    Cabecalho 'PREPARANDO O DISCO'

    $partC = Get-Partition -DriveLetter C -ErrorAction Stop
    $numDisco = $partC.DiskNumber

    $esp = Get-Partition -DiskNumber $numDisco -ErrorAction SilentlyContinue |
           Where-Object { $_.GptType -eq '{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}' } |
           Select-Object -First 1

    $fw = Obter-Firmware
    if ($fw.Modo -eq 'UEFI' -and -not $esp) {
        throw 'Nao encontrei a particao de sistema (EFI). Este disco nao tem o layout esperado.'
    }

    Write-Host "  Disco .............: $numDisco" -ForegroundColor White
    Write-Host "  Particao do Windows: $($partC.PartitionNumber) (C:)" -ForegroundColor White
    if ($esp) { Write-Host "  Particao de sistema: $($esp.PartitionNumber) (EFI)" -ForegroundColor White }
    Write-Host ''

    # ------------------------------------------------ Area de trabalho
    #
    # Se a imagem foi baixada da rede, ela JA esta dentro da particao DEPLOY.
    # Nesse caso nao se cria nada e nao se copia nada: os arquivos so mudam
    # de pasta dentro da mesma particao, o que e instantaneo.

    $srcDir = Split-Path $md.Imagem -Parent
    $areaJa = Obter-AreaStaging
    $naArea = $false

    if ($areaJa) {
        $qualImagem = (Split-Path $srcDir -Qualifier)
        $qualArea   = "$($areaJa.DriveLetter):"
        $naArea     = ($qualImagem -ieq $qualArea)
    }

    if ($naArea) {
        $letra = $areaJa.DriveLetter
        Write-Host "  A imagem ja esta na area de trabalho (${letra}:)." -ForegroundColor Green
        Write-Host '  Nada para copiar.' -ForegroundColor Gray
        Write-Host ''
    } else {
        $gb = [math]::Ceiling($md.Tamanho / 1GB) + 4
        Write-Host "  Criando area de trabalho de $gb GB..." -ForegroundColor Gray
        Write-Host ''

        $letra = Criar-AreaStaging -GbNecessarios $gb
        if (-not $letra) { throw 'Nao foi possivel criar a area de trabalho em disco.' }
    }

    $area = "${letra}:\DEPLOY"
    New-Item -ItemType Directory -Path $area -Force | Out-Null

    # ------------------------------------------------ Posicionar a imagem
    $partes = @(Get-ChildItem $srcDir | Where-Object { $_.Name -match '^install.*\.(wim|esd|swm)$' })

    # Mesma particao = mover (renomear, instantaneo). Particoes diferentes = copiar.
    $mesmoVolume = ((Split-Path $srcDir -Qualifier) -ieq (Split-Path $area -Qualifier))

    if ($mesmoVolume) {
        Cabecalho 'POSICIONANDO A IMAGEM'
        Write-Host '  Mesma particao: e so mover, leva segundos.' -ForegroundColor Gray
    } else {
        Cabecalho 'COPIANDO A IMAGEM'
        Write-Host '  Isto leva de 5 a 20 minutos. Nao feche esta janela.' -ForegroundColor Yellow
    }
    Write-Host ''

    $i = 0
    foreach ($p in $partes) {
        $i++
        $alvo = Join-Path $area $p.Name
        if ($alvo -ieq $p.FullName) { continue }   # ja esta no lugar certo

        Write-Host ("  ({0}/{1}) {2}  -  {3}" -f $i, $partes.Count, $p.Name, (Formatar-Tamanho $p.Length)) -ForegroundColor Gray
        if ($mesmoVolume) {
            Move-Item $p.FullName $alvo -Force
        } else {
            Copy-Item $p.FullName $alvo -Force
        }
    }
    Write-Host '  Imagem pronta.' -ForegroundColor Green

    # unattend.xml, se existir na midia
    $ua = Join-Path (Split-Path $srcDir -Parent) 'autounattend.xml'
    if (-not (Test-Path $ua)) { $ua = Join-Path $srcDir 'unattend.xml' }
    if (Test-Path $ua) {
        Copy-Item $ua (Join-Path $area 'unattend.xml') -Force
        Write-Host '  Configuracao automatica incluida.' -ForegroundColor Green
    }

    # ------------------------------------------------ Marcador do alvo
    "Esta particao sera formatada pelo Sistema de Formatacao." |
        Out-File 'C:\ALVO_FORMATACAO.txt' -Encoding ASCII -Force

    # ------------------------------------------------ Armar
    $tarefa = @{
        MODO    = 'REAL'
        IMAGEM  = $md.ImagemNome
        INDICE  = $Indice
        NOME    = $nomeEd
        DISCO   = $numDisco
        PARTESP = $(if ($esp) { $esp.PartitionNumber } else { '' })
    }

    if (-not (Armar-Boot -Tarefa $tarefa -Destino $area)) {
        throw 'Nao foi possivel preparar a inicializacao.'
    }

    Write-Host ''
    Write-Host '  ================================================================' -ForegroundColor Yellow
    Write-Host '   TUDO PRONTO' -ForegroundColor Yellow
    Write-Host '  ================================================================' -ForegroundColor Yellow
    Write-Host '   Ao reiniciar, o Windows sera apagado e regravado.' -ForegroundColor Yellow
    Write-Host '   NAO DESLIGUE o equipamento durante o processo.' -ForegroundColor Yellow
    Write-Host ''
    $c3 = Read-Host '  Reiniciar e formatar agora? (digite FORMATAR)'
    if ($c3 -eq 'FORMATAR') {
        & shutdown.exe /r /t 30 /c 'Sistema de Formatacao - iniciando'
        Write-Host '  Reiniciando em 30 segundos... (cancelar: shutdown /a)' -ForegroundColor Cyan
        Start-Sleep -Seconds 5
    } else {
        Write-Host '  Cancelado. Use "Cancelar / Reverter" para desarmar.' -ForegroundColor Yellow
        Pausar
    }
}

# =================================================================
'desarmar' {
    Cabecalho 'CANCELAR / REVERTER'
    foreach ($n in 67..90) {
        $l = [char]$n
        if (Test-Path "${l}:\DEPLOY\boot-estado.json") { Desarmar-Boot -Destino "${l}:\DEPLOY" | Out-Null }
    }
    Desarmar-Boot -Destino 'C:\DEPLOY' | Out-Null
    Write-Host ''
    Write-Host '  O computador voltou a inicializar normalmente no Windows.' -ForegroundColor Green
    Pausar
}

# =================================================================
'limpar-staging' {
    Cabecalho 'REMOVER AREA DE TRABALHO'
    Write-Host '  Isto apaga a particao DEPLOY e devolve o espaco ao C:.' -ForegroundColor Yellow
    Write-Host ''
    $r = Read-Host '  Confirmar? (S/N)'
    if ($r -match '^[SsYy]') { Remover-AreaStaging | Out-Null } else { Write-Host '  Cancelado.' -ForegroundColor Gray }
    Pausar
}

} # switch
}
catch {
    Write-Host ''
    Write-Host '  ================================================' -ForegroundColor Red
    Write-Host '   ERRO' -ForegroundColor Red
    Write-Host '  ================================================' -ForegroundColor Red
    Write-Host "   $_" -ForegroundColor Red
    Write-Host ''
    Write-Host "   Registro completo: $Global:LOG_ATUAL" -ForegroundColor Gray
    Escrever-Log "ERRO em '$Acao': $_" ERRO -SemConsole
    Pausar
}
