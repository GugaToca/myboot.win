<#
    winpe.ps1 - Monta o ambiente WinPE automaticamente
    Chamado pela interface. Nao precisa ser executado direto.
#>

function Instalar-WinPEPronto {
    <#
      Coloca no lugar um ambiente que JA veio montado do servidor.

      Montar o WinPE (abrir o WIM, injetar os scripts, salvar) leva de
      5 a 15 minutos e da exatamente o mesmo resultado em toda maquina.
      Entao isso e feito uma vez so, no servidor, e cada maquina apenas
      copia o resultado. Aqui a conta e de segundos.
    #>
    param(
        [Parameter(Mandatory)][string]$ArquivoWim,
        [string]$ArquivoSdi
    )

    Escrever-Log "=========================================" PASSO
    Escrever-Log " INSTALANDO O AMBIENTE PRONTO" PASSO
    Escrever-Log "=========================================" PASSO

    if (-not (Test-Path $ArquivoWim)) {
        Escrever-Log "Ambiente pronto nao encontrado: $ArquivoWim" ERRO
        return $false
    }

    if (-not (Test-Path $Global:PASTA_PE)) {
        New-Item -ItemType Directory -Path $Global:PASTA_PE -Force | Out-Null
    }

    try {
        Copy-Item $ArquivoWim (Join-Path $Global:PASTA_PE 'boot.wim') -Force
        Escrever-Log ("boot.wim instalado ({0})" -f (Formatar-Tamanho (Get-Item $ArquivoWim).Length)) OK
    } catch {
        Escrever-Log "Falha ao copiar o ambiente: $_" ERRO
        return $false
    }

    # ---------------------------------------------------- boot.sdi
    $sdiDestino = Join-Path $Global:PASTA_PE 'boot.sdi'
    $sdiOrigem  = $null

    if ($ArquivoSdi -and (Test-Path $ArquivoSdi)) {
        $sdiOrigem = $ArquivoSdi
    } else {
        foreach ($cand in @(
            'C:\Windows\Boot\DVD\PCAT\boot.sdi',
            'C:\Recovery\WindowsRE\boot.sdi')) {
            if (Test-Path $cand) { $sdiOrigem = $cand; break }
        }
        if (-not $sdiOrigem) {
            $adk = Obter-CaminhosAdk
            if ($adk -and (Test-Path $adk.BootSdi)) { $sdiOrigem = $adk.BootSdi }
        }
    }

    if (-not $sdiOrigem) {
        Escrever-Log "boot.sdi nao encontrado em lugar nenhum." ERRO
        return $false
    }

    try {
        Copy-Item $sdiOrigem $sdiDestino -Force
        Escrever-Log "boot.sdi obtido de: $sdiOrigem" OK
    } catch {
        Escrever-Log "Falha ao copiar o boot.sdi: $_" ERRO
        return $false
    }

    $cfg = Ler-Config
    $cfg.WinPEPronto = $true
    $cfg.DataWinPE   = (Get-Date -Format 'dd/MM/yyyy HH:mm')
    Salvar-Config $cfg

    $mb = [math]::Round((Get-Item (Join-Path $Global:PASTA_PE 'boot.wim')).Length/1MB)
    Escrever-Log "=========================================" OK
    Escrever-Log " AMBIENTE PRONTO - $mb MB" OK
    Escrever-Log "=========================================" OK
    return $true
}

function Construir-WinPE-DaMidia {
    <#
      Prepara o ambiente de formatacao usando o boot.wim que veio
      DENTRO da midia de instalacao do usuario.

      Vantagem: nao precisa do Windows ADK. O DISM usado aqui ja
      vem no Windows 10/11 Pro.
    #>
    param([Parameter(Mandatory)][string]$BootWimOrigem)

    Escrever-Log "=========================================" PASSO
    Escrever-Log " PREPARANDO O AMBIENTE DE FORMATACAO" PASSO
    Escrever-Log " (usando o boot.wim da sua propria midia)" PASSO
    Escrever-Log "=========================================" PASSO

    if (-not (Test-Path $BootWimOrigem)) {
        Escrever-Log "boot.wim nao encontrado: $BootWimOrigem" ERRO
        return $false
    }

    $trabalho = 'C:\WinPE_Build'
    $mount    = Join-Path $trabalho 'mount'
    $wimTmp   = Join-Path $trabalho 'boot.wim'

    # ---------------------------------------------------- Limpeza previa
    $mnt = Get-WindowsImage -Mounted -ErrorAction SilentlyContinue
    foreach ($m in $mnt) {
        Escrever-Log "Descartando montagem presa em $($m.Path)" AVISO
        Dismount-WindowsImage -Path $m.Path -Discard -ErrorAction SilentlyContinue | Out-Null
    }
    if ($mnt) { Clear-WindowsCorruptMountPoint -ErrorAction SilentlyContinue | Out-Null }

    if (Test-Path $trabalho) { Remove-Item $trabalho -Recurse -Force -ErrorAction SilentlyContinue }
    New-Item -ItemType Directory -Path $mount -Force | Out-Null

    # ---------------------------------------------------- Copia
    Escrever-Log "Copiando o ambiente de boot da midia..." PASSO
    try {
        Copy-Item $BootWimOrigem $wimTmp -Force
        Set-ItemProperty $wimTmp -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
    } catch {
        Escrever-Log "Falha ao copiar: $_" ERRO
        return $false
    }
    Escrever-Log ("Copiado ({0})" -f (Formatar-Tamanho (Get-Item $wimTmp).Length)) OK

    # ---------------------------------------------------- Escolher o indice
    $idx = 1
    try {
        $imgs = @(Get-WindowsImage -ImagePath $wimTmp -ErrorAction Stop)
        # Se houver mais de um, o ultimo costuma ser o ambiente de instalacao
        if ($imgs.Count -gt 1) { $idx = ($imgs | Select-Object -Last 1).ImageIndex }
        Escrever-Log "Usando indice $idx de $($imgs.Count)" INFO
    } catch {
        Escrever-Log "Nao consegui listar os indices, usando 1" AVISO
    }

    # ---------------------------------------------------- Montar
    Escrever-Log "Abrindo o ambiente (1 a 4 minutos)..." PASSO
    try {
        Mount-WindowsImage -ImagePath $wimTmp -Index $idx -Path $mount -ErrorAction Stop | Out-Null
    } catch {
        Escrever-Log "Falha ao abrir: $_" ERRO
        return $false
    }
    Escrever-Log "Ambiente aberto" OK

    $sucesso = $false
    try {
        $sys32  = Join-Path $mount 'Windows\System32'
        $origem = Join-Path $Global:SISTEMA 'winpe-arquivos'

        # Se a midia estiver configurada para abrir o instalador do Windows,
        # remove esse gatilho para que o nosso script rode no lugar.
        $shl = Join-Path $sys32 'winpeshl.ini'
        if (Test-Path $shl) {
            Copy-Item $shl "$shl.original" -Force -ErrorAction SilentlyContinue
            Remove-Item $shl -Force -ErrorAction SilentlyContinue
            Escrever-Log "Instalador padrao do Windows desativado neste ambiente" OK
        }

        Escrever-Log "Instalando os scripts de formatacao..." PASSO
        foreach ($arq in @('startnet.cmd','deploy.cmd')) {
            $src = Join-Path $origem $arq
            if (-not (Test-Path $src)) { throw "Arquivo do sistema ausente: $src" }
            Copy-Item $src (Join-Path $sys32 $arq) -Force
        }

        # deploy.ps1 e opcional: so funciona se este WinPE tiver PowerShell
        $psSrc = Join-Path $origem 'deploy.ps1'
        if (Test-Path $psSrc) { Copy-Item $psSrc (Join-Path $sys32 'deploy.ps1') -Force }

        Escrever-Log "Scripts instalados" OK

        & dism.exe /Image:$mount /Set-ScratchSpace:512 2>&1 | Out-Null

        # ------------------------------------------------ Drivers extras
        $drv = Join-Path $Global:RAIZ 'drivers'
        if (Test-Path $drv) {
            $infs = @(Get-ChildItem $drv -Filter *.inf -Recurse -ErrorAction SilentlyContinue)
            if ($infs.Count -gt 0) {
                Escrever-Log "Injetando $($infs.Count) driver(s)..." PASSO
                Add-WindowsDriver -Path $mount -Driver $drv -Recurse -ForceUnsigned -ErrorAction SilentlyContinue | Out-Null
                Escrever-Log "Drivers injetados" OK
            }
        }

        $sucesso = $true
    }
    catch {
        Escrever-Log "Erro ao preparar: $_" ERRO
    }
    finally {
        Escrever-Log "Salvando o ambiente (2 a 5 minutos)..." PASSO
        try {
            if ($sucesso) { Dismount-WindowsImage -Path $mount -Save -ErrorAction Stop | Out-Null }
            else          { Dismount-WindowsImage -Path $mount -Discard -ErrorAction SilentlyContinue | Out-Null }
        } catch {
            Escrever-Log "Falha ao salvar: $_" ERRO
            $sucesso = $false
        }
    }

    if (-not $sucesso) { return $false }

    # ---------------------------------------------------- Publicar
    try {
        Copy-Item $wimTmp (Join-Path $Global:PASTA_PE 'boot.wim') -Force

        # boot.sdi: procura na midia, senao no ADK, senao no proprio Windows
        $sdiDestino = Join-Path $Global:PASTA_PE 'boot.sdi'
        $sdiOrigem = $null

        $pastaMidia = Split-Path (Split-Path $BootWimOrigem -Parent) -Parent
        foreach ($cand in @(
            (Join-Path $pastaMidia 'Boot\boot.sdi'),
            (Join-Path $pastaMidia 'boot\boot.sdi'),
            'C:\Windows\Boot\DVD\PCAT\boot.sdi',
            'C:\Recovery\WindowsRE\boot.sdi')) {
            if (Test-Path $cand) { $sdiOrigem = $cand; break }
        }
        if (-not $sdiOrigem) {
            $adk = Obter-CaminhosAdk
            if ($adk -and (Test-Path $adk.BootSdi)) { $sdiOrigem = $adk.BootSdi }
        }
        if (-not $sdiOrigem) { throw "boot.sdi nao encontrado em lugar nenhum." }

        Copy-Item $sdiOrigem $sdiDestino -Force
        Escrever-Log "boot.sdi obtido de: $sdiOrigem" OK
    }
    catch {
        Escrever-Log "Falha ao publicar: $_" ERRO
        return $false
    }

    $cfg = Ler-Config
    $cfg.WinPEPronto = $true
    $cfg.DataWinPE   = (Get-Date -Format 'dd/MM/yyyy HH:mm')
    Salvar-Config $cfg

    $mb = [math]::Round((Get-Item (Join-Path $Global:PASTA_PE 'boot.wim')).Length/1MB)
    Escrever-Log "=========================================" OK
    Escrever-Log " AMBIENTE PRONTO - $mb MB" OK
    Escrever-Log "=========================================" OK

    Remove-Item $trabalho -Recurse -Force -ErrorAction SilentlyContinue
    return $true
}

function Construir-WinPE {
    param([switch]$Refazer)

    Escrever-Log "=========================================" PASSO
    Escrever-Log " MONTANDO O AMBIENTE DE FORMATACAO" PASSO
    Escrever-Log "=========================================" PASSO

    $adk = Obter-CaminhosAdk
    if (-not $adk -or -not $adk.Completo) {
        Escrever-Log "Windows ADK + add-on WinPE nao encontrados." ERRO
        return $false
    }
    Escrever-Log "ADK localizado: $($adk.Kits)" OK

    $trabalho = 'C:\WinPE_Build'
    $mount    = Join-Path $trabalho 'mount'
    $wimTmp   = Join-Path $trabalho 'boot.wim'

    # ---------------------------------------------------- Limpeza previa
    Escrever-Log "Verificando montagens anteriores..." PASSO
    $mnt = Get-WindowsImage -Mounted -ErrorAction SilentlyContinue
    foreach ($m in $mnt) {
        Escrever-Log "Descartando montagem presa em $($m.Path)" AVISO
        Dismount-WindowsImage -Path $m.Path -Discard -ErrorAction SilentlyContinue | Out-Null
    }
    if ($mnt) { Clear-WindowsCorruptMountPoint -ErrorAction SilentlyContinue | Out-Null }

    if ($Refazer -and (Test-Path $trabalho)) {
        Remove-Item $trabalho -Recurse -Force -ErrorAction SilentlyContinue
    }
    New-Item -ItemType Directory -Path $mount -Force | Out-Null

    # ---------------------------------------------------- Copia base
    Escrever-Log "Copiando base do WinPE..." PASSO
    try {
        Copy-Item $adk.WinpeWim $wimTmp -Force
        Set-ItemProperty $wimTmp -Name IsReadOnly -Value $false -ErrorAction SilentlyContinue
    } catch {
        Escrever-Log "Falha ao copiar winpe.wim: $_" ERRO
        return $false
    }
    Escrever-Log ("Base copiada ({0})" -f (Formatar-Tamanho (Get-Item $wimTmp).Length)) OK

    # ---------------------------------------------------- Monta
    Escrever-Log "Abrindo a imagem (1 a 3 minutos, aguarde)..." PASSO
    try {
        Mount-WindowsImage -ImagePath $wimTmp -Index 1 -Path $mount -ErrorAction Stop | Out-Null
    } catch {
        Escrever-Log "Falha ao montar: $_" ERRO
        return $false
    }
    Escrever-Log "Imagem aberta" OK

    $sucesso = $false
    try {
        # ------------------------------------------------ Pacotes
        # Ordem obrigatoria - ha dependencia entre eles
        $pacotes = @(
            'WinPE-WMI', 'WinPE-NetFx', 'WinPE-Scripting', 'WinPE-PowerShell',
            'WinPE-StorageWMI', 'WinPE-DismCmdlets', 'WinPE-EnhancedStorage',
            'WinPE-SecureStartup', 'WinPE-FMAPI'
        )

        Escrever-Log "Instalando componentes (5 a 12 minutos)..." PASSO
        $i = 0
        foreach ($pkg in $pacotes) {
            $i++
            $cab = Join-Path $adk.Ocs "$pkg.cab"
            if (-not (Test-Path $cab)) { Escrever-Log "  ($i/$($pacotes.Count)) $pkg - ausente, pulando" AVISO; continue }

            Escrever-Log "  ($i/$($pacotes.Count)) $pkg" INFO
            Add-WindowsPackage -Path $mount -PackagePath $cab -ErrorAction Stop | Out-Null

            $lp = Join-Path $adk.Ocs "en-us\${pkg}_en-us.cab"
            if (Test-Path $lp) {
                Add-WindowsPackage -Path $mount -PackagePath $lp -ErrorAction SilentlyContinue | Out-Null
            }
        }
        Escrever-Log "Componentes instalados" OK

        # ------------------------------------------------ Scratch
        & dism.exe /Image:$mount /Set-ScratchSpace:512 2>&1 | Out-Null
        Escrever-Log "Espaco de trabalho em RAM: 512 MB" OK

        # ------------------------------------------------ Scripts
        Escrever-Log "Instalando scripts de formatacao..." PASSO
        $sys32  = Join-Path $mount 'Windows\System32'
        $origem = Join-Path $Global:SISTEMA 'winpe-arquivos'

        foreach ($arq in @('startnet.cmd','deploy.ps1')) {
            $src = Join-Path $origem $arq
            if (-not (Test-Path $src)) { throw "Arquivo do sistema ausente: $src" }
            Copy-Item $src (Join-Path $sys32 $arq) -Force
        }
        Escrever-Log "Scripts instalados" OK

        # ------------------------------------------------ Drivers extras
        $drv = Join-Path $Global:RAIZ 'drivers'
        if (Test-Path $drv) {
            $infs = @(Get-ChildItem $drv -Filter *.inf -Recurse -ErrorAction SilentlyContinue)
            if ($infs.Count -gt 0) {
                Escrever-Log "Injetando $($infs.Count) driver(s) da pasta 'drivers'..." PASSO
                Add-WindowsDriver -Path $mount -Driver $drv -Recurse -ForceUnsigned -ErrorAction SilentlyContinue | Out-Null
                Escrever-Log "Drivers injetados" OK
            }
        }

        $sucesso = $true
    }
    catch {
        Escrever-Log "Erro durante a montagem: $_" ERRO
    }
    finally {
        Escrever-Log "Fechando e salvando a imagem (2 a 5 minutos)..." PASSO
        try {
            if ($sucesso) { Dismount-WindowsImage -Path $mount -Save -ErrorAction Stop | Out-Null }
            else          { Dismount-WindowsImage -Path $mount -Discard -ErrorAction SilentlyContinue | Out-Null }
        } catch {
            Escrever-Log "Falha ao fechar a imagem: $_" ERRO
            $sucesso = $false
        }
    }

    if (-not $sucesso) { return $false }

    # ---------------------------------------------------- Publica
    try {
        Copy-Item $wimTmp        (Join-Path $Global:PASTA_PE 'boot.wim') -Force
        Copy-Item $adk.BootSdi   (Join-Path $Global:PASTA_PE 'boot.sdi') -Force
    } catch {
        Escrever-Log "Falha ao publicar arquivos: $_" ERRO
        return $false
    }

    $cfg = Ler-Config
    $cfg.WinPEPronto = $true
    $cfg.DataWinPE   = (Get-Date -Format 'dd/MM/yyyy HH:mm')
    Salvar-Config $cfg

    $mb = [math]::Round((Get-Item (Join-Path $Global:PASTA_PE 'boot.wim')).Length/1MB)
    Escrever-Log "=========================================" OK
    Escrever-Log " AMBIENTE PRONTO - $mb MB" OK
    Escrever-Log " Local: $Global:PASTA_PE" OK
    Escrever-Log "=========================================" OK

    Remove-Item $trabalho -Recurse -Force -ErrorAction SilentlyContinue
    return $true
}
