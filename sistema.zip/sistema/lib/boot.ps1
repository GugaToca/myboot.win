<#
    boot.ps1 - Cria e remove a entrada de boot temporaria (BCD)

    SEGURANCA: usa sempre /bootsequence (boot de uso unico).
    Se o ambiente nao carregar, o proximo boot volta ao Windows sozinho.
#>

function Invoke-Bcd {
    param([string[]]$Argumentos, [switch]$Silencioso)
    $saida = & bcdedit.exe @Argumentos 2>&1
    $txt = ($saida | Out-String)
    if ($LASTEXITCODE -ne 0 -and -not $Silencioso) {
        throw "bcdedit falhou em: $($Argumentos -join ' ')`n$txt"
    }
    return $txt
}

function Garantir-OpcoesRamdisk {
    <#
      Garante que existe uma entrada de opcoes de ramdisk configurada.

      O bcdedit as vezes devolve "sucesso" mesmo quando a entrada nao
      existe, entao NAO da para confiar no codigo de saida. Aqui a
      verificacao e feita tentando configurar de verdade.

      Devolve o identificador a usar, ou $null se nada funcionar.
    #>
    param(
        [Parameter(Mandatory)][string]$Volume,     # ex: "C:"
        [Parameter(Mandatory)][string]$CaminhoSdi  # ex: "\DEPLOY\boot.sdi"
    )

    function Tentar-Configurar([string]$id) {
        & bcdedit.exe /set $id ramdisksdidevice "partition=$Volume" 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { return $false }
        & bcdedit.exe /set $id ramdisksdipath $CaminhoSdi 2>&1 | Out-Null
        return ($LASTEXITCODE -eq 0)
    }

    # ---- Tentativa 1: usar a entrada padrao, criando se preciso
    & bcdedit.exe /create '{ramdiskoptions}' /d 'Sistema de Formatacao' 2>&1 | Out-Null
    if (Tentar-Configurar '{ramdiskoptions}') {
        Escrever-Log "Opcoes de ramdisk configuradas" OK
        return '{ramdiskoptions}'
    }

    # ---- Tentativa 2: apagar a entrada quebrada e recriar
    Escrever-Log "Entrada padrao nao aceitou configuracao. Recriando..." AVISO
    & bcdedit.exe /delete '{ramdiskoptions}' /f 2>&1 | Out-Null
    & bcdedit.exe /create '{ramdiskoptions}' /d 'Sistema de Formatacao' 2>&1 | Out-Null
    if (Tentar-Configurar '{ramdiskoptions}') {
        Escrever-Log "Opcoes de ramdisk recriadas" OK
        return '{ramdiskoptions}'
    }

    # ---- Tentativa 3: criar uma entrada de dispositivo com GUID proprio
    Escrever-Log "Criando entrada de dispositivo independente..." AVISO
    $saida = (& bcdedit.exe /create /d 'Opcoes de Ramdisk - Formatacao' /device 2>&1 | Out-String)
    if ($saida -match '(\{[0-9a-fA-F\-]{36}\})') {
        $id = $Matches[1]
        if (Tentar-Configurar $id) {
            Escrever-Log "Opcoes de ramdisk criadas: $id" OK
            return $id
        }
        & bcdedit.exe /delete $id /f 2>&1 | Out-Null
    }

    Escrever-Log "Nao consegui criar as opcoes de ramdisk." ERRO
    Escrever-Log "Resposta do sistema: $($saida.Trim())" INFO
    return $null
}

function Escrever-Tarefa {
    <# Grava tarefa.txt no formato CHAVE=VALOR (lido pelo deploy.cmd). #>
    param(
        [Parameter(Mandatory)][string]$Pasta,
        [Parameter(Mandatory)][hashtable]$Dados
    )
    $linhas = @()
    foreach ($k in $Dados.Keys) { $linhas += "$k=$($Dados[$k])" }
    $linhas += "CRIADOEM=$(Get-Date -Format 's')"
    $linhas += "MAQUINA=$env:COMPUTERNAME"

    # ASCII de proposito: o CMD do WinPE nao le UTF-8 com BOM
    $linhas -join "`r`n" | Out-File (Join-Path $Pasta 'tarefa.txt') -Encoding ASCII -Force
}

function Armar-Boot {
    <#
      Copia o ambiente para <Destino>\, grava a tarefa, cria a entrada
      BCD e agenda o boot de uso unico.

      $Destino deve ser a RAIZ de um volume + \DEPLOY
      Exemplos: C:\DEPLOY  ou  E:\DEPLOY
    #>
    param(
        [Parameter(Mandatory)][hashtable]$Tarefa,
        [string]$Destino = 'C:\DEPLOY',
        [switch]$PularCopiaAmbiente
    )

    Escrever-Log "=========================================" PASSO
    Escrever-Log " PREPARANDO A INICIALIZACAO" PASSO
    Escrever-Log "=========================================" PASSO

    $wim = Join-Path $Global:PASTA_PE 'boot.wim'
    $sdi = Join-Path $Global:PASTA_PE 'boot.sdi'
    foreach ($f in @($wim,$sdi)) {
        if (-not (Test-Path $f)) { Escrever-Log "Ambiente nao preparado: falta $f" ERRO; return $false }
    }

    $vol = (Split-Path $Destino -Qualifier)          # ex: "C:"

    # -------------------------------------------------- Verificacoes
    $wimMb = [math]::Round((Get-Item $wim).Length/1MB)
    $ramMb = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1MB)
    if ($ramMb -lt ($wimMb*2 + 1024)) {
        Escrever-Log "Memoria insuficiente: o ambiente ($wimMb MB) nao cabe na RAM." ERRO
        return $false
    }

    try {
        $bl = Get-BitLockerVolume -MountPoint $vol -ErrorAction Stop
        if ($bl.ProtectionStatus -eq 'On') {
            Escrever-Log "BitLocker esta LIGADO em $vol. Suspenda antes de continuar." ERRO
            Escrever-Log "Comando: Suspend-BitLocker -MountPoint $vol -RebootCount 2" INFO
            return $false
        }
    } catch {}

    $fw = Obter-Firmware
    if (-not $fw.Loader) {
        Escrever-Log "Nao identifiquei o modo de firmware (UEFI ou BIOS)." ERRO
        Escrever-Log "O que cada metodo respondeu:" INFO
        Escrever-Log "  $($fw.Tentativas)" INFO
        Escrever-Log "" INFO
        Escrever-Log "Tire uma foto desta tela e envie para analise." AVISO
        return $false
    }
    Escrever-Log "Firmware: $($fw.Modo) (detectado via $($fw.Via))" OK
    Escrever-Log "Secure Boot: $($fw.SecureBootTxt)" OK

    $bat = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
    if ($bat -and $bat.BatteryStatus -ne 2 -and $bat.EstimatedChargeRemaining -lt 40) {
        Escrever-Log "Conecte o carregador (bateria em $($bat.EstimatedChargeRemaining)%)." ERRO
        return $false
    }

    # -------------------------------------------------- Copiar ambiente
    New-Item -ItemType Directory -Path $Destino -Force | Out-Null

    if (-not $PularCopiaAmbiente) {
        Escrever-Log "Copiando o ambiente para $Destino ..." PASSO
        Copy-Item $wim (Join-Path $Destino 'boot.wim') -Force
        Copy-Item $sdi (Join-Path $Destino 'boot.sdi') -Force
        Escrever-Log "Ambiente copiado" OK
    }

    'Marcador do sistema de formatacao.' |
        Out-File (Join-Path $Destino 'MARCADOR.txt') -Encoding ASCII -Force

    Escrever-Tarefa -Pasta $Destino -Dados $Tarefa

    # -------------------------------------------------- BCD
    try {
        $bkp = Join-Path $Destino 'bcd-backup.bcd'
        if (Test-Path $bkp) { Remove-Item $bkp -Force -ErrorAction SilentlyContinue }
        Invoke-Bcd @('/export', $bkp) | Out-Null
        Escrever-Log "Backup da configuracao de boot salvo" OK

        $idRd = Garantir-OpcoesRamdisk -Volume $vol -CaminhoSdi '\DEPLOY\boot.sdi'
        if (-not $idRd) { throw 'Nao foi possivel configurar as opcoes de ramdisk.' }

        $saida = Invoke-Bcd @('/create','/d','Modo de Formatacao','/application','osloader')
        if ($saida -notmatch '(\{[0-9a-fA-F\-]{36}\})') { throw "Nao consegui criar a entrada de boot.`n$saida" }
        $guid = $Matches[1]

        $rd = "ramdisk=[$vol]\DEPLOY\boot.wim,$idRd"
        Invoke-Bcd @('/set',$guid,'device',    $rd)          | Out-Null
        Invoke-Bcd @('/set',$guid,'osdevice',  $rd)          | Out-Null
        Invoke-Bcd @('/set',$guid,'path',      $fw.Loader)   | Out-Null
        Invoke-Bcd @('/set',$guid,'systemroot','\windows')   | Out-Null
        Invoke-Bcd @('/set',$guid,'detecthal', 'yes')        | Out-Null
        Invoke-Bcd @('/set',$guid,'winpe',     'yes')        | Out-Null

        # >>> BOOT DE USO UNICO - protecao principal do sistema <<<
        Invoke-Bcd @('/bootsequence',$guid) | Out-Null

        @{ Guid = $guid; Ramdisk = $idRd; Volume = $vol; Destino = $Destino } |
            ConvertTo-Json | Out-File (Join-Path $Destino 'boot-estado.json') -Encoding UTF8 -Force

        Escrever-Log "Entrada de boot criada: $guid" OK
        Escrever-Log "Agendada para UMA unica inicializacao" OK
        return $true
    }
    catch {
        Escrever-Log "Falha ao configurar o boot: $_" ERRO
        Desarmar-Boot -Destino $Destino | Out-Null
        return $false
    }
}

function Desarmar-Boot {
    param([string]$Destino = 'C:\DEPLOY')

    Escrever-Log "Revertendo configuracao de boot..." PASSO
    $guid = $null

    $idRd = $null
    $arq = Join-Path $Destino 'boot-estado.json'
    if (Test-Path $arq) {
        try {
            $st = Get-Content $arq -Raw -Encoding UTF8 | ConvertFrom-Json
            $guid = $st.Guid
            $idRd = $st.Ramdisk
        } catch {}
    }

    if (-not $guid) {
        $todos = (& bcdedit.exe /enum all) | Out-String
        $blocos = $todos -split "(?m)^(?=Windows Boot Loader|Carregador)"
        foreach ($b in $blocos) {
            if ($b -match 'Modo de Formatacao' -and $b -match '(\{[0-9a-fA-F\-]{36}\})') { $guid = $Matches[1]; break }
        }
    }

    & bcdedit.exe /bootsequence "{default}" 2>&1 | Out-Null

    if ($guid) {
        & bcdedit.exe /delete $guid /f 2>&1 | Out-Null
        Escrever-Log "Entrada removida: $guid" OK
    } else {
        Escrever-Log "Nenhuma entrada pendente encontrada" INFO
    }

    if ($idRd -and $idRd -ne '{ramdiskoptions}') {
        & bcdedit.exe /delete $idRd /f 2>&1 | Out-Null
    }
    & bcdedit.exe /delete "{ramdiskoptions}" /f 2>&1 | Out-Null

    # Remove o marcador de alvo, se tiver ficado para tras
    Remove-Item 'C:\ALVO_FORMATACAO.txt' -Force -ErrorAction SilentlyContinue

    if (Test-Path $arq) { Remove-Item $arq -Force -ErrorAction SilentlyContinue }
    Escrever-Log "Boot restaurado ao normal" OK
    return $true
}

function Obter-ResultadoWinPE {
    <#
      Le o resultado.txt (CHAVE=VALOR) deixado pelo ambiente na
      ultima execucao. Procura em todos os volumes.
    #>
    foreach ($n in 67..90) {
        $l = [char]$n
        $arq = "${l}:\DEPLOY\resultado.txt"
        if (Test-Path $arq) {
            $h = @{}
            foreach ($linha in (Get-Content $arq -ErrorAction SilentlyContinue)) {
                if ($linha -match '^\s*([^=]+)=(.*)$') { $h[$Matches[1].Trim()] = $Matches[2].Trim() }
            }
            $h['_Arquivo'] = $arq
            $h['_Quando']  = (Get-Item $arq).LastWriteTime
            return $h
        }
    }
    return $null
}
