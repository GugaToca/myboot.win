<#
    menu.ps1 - Interface grafica do Sistema de Formatacao
    Aberto pelo INICIAR.bat. Nao precisa ser executado direto.
#>

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

$lib = Join-Path $PSScriptRoot 'lib'
. (Join-Path $lib 'comum.ps1')
. (Join-Path $lib 'boot.ps1')
. (Join-Path $lib 'disco.ps1')
. (Join-Path $lib 'midia.ps1')

# ============================================================ ESTILO

$C_Fundo    = [System.Drawing.Color]::FromArgb(243,244,246)
$C_Escuro   = [System.Drawing.Color]::FromArgb(30,41,59)
$C_Roxo     = [System.Drawing.Color]::FromArgb(124,58,237)
$C_Azul     = [System.Drawing.Color]::FromArgb(37,99,235)
$C_Verde    = [System.Drawing.Color]::FromArgb(22,163,74)
$C_Vermelho = [System.Drawing.Color]::FromArgb(220,38,38)
$C_Cinza    = [System.Drawing.Color]::FromArgb(107,114,128)
$C_Inativo  = [System.Drawing.Color]::FromArgb(203,213,225)
$C_Branco   = [System.Drawing.Color]::White

$F_Titulo = New-Object System.Drawing.Font('Segoe UI', 16, [System.Drawing.FontStyle]::Bold)
$F_Sub    = New-Object System.Drawing.Font('Segoe UI', 9)
$F_Cabec  = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$F_Texto  = New-Object System.Drawing.Font('Segoe UI', 9)
$F_Botao  = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$F_Mini   = New-Object System.Drawing.Font('Segoe UI', 8)

# ============================================================ JANELA

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Sistema de Formatacao'
$form.Size = New-Object System.Drawing.Size(960, 760)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $C_Fundo
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false

$cab = New-Object System.Windows.Forms.Panel
$cab.Size = New-Object System.Drawing.Size(960, 70)
$cab.BackColor = $C_Escuro
$form.Controls.Add($cab)

$lblT = New-Object System.Windows.Forms.Label
$lblT.Text = 'Sistema de Formatacao'
$lblT.Font = $F_Titulo
$lblT.ForeColor = $C_Branco
$lblT.Location = New-Object System.Drawing.Point(22, 12)
$lblT.Size = New-Object System.Drawing.Size(500, 30)
$cab.Controls.Add($lblT)

$lblS = New-Object System.Windows.Forms.Label
$lblS.Text = 'Formatacao sem pendrive, com o computador ligado'
$lblS.Font = $F_Sub
$lblS.ForeColor = [System.Drawing.Color]::FromArgb(148,163,184)
$lblS.Location = New-Object System.Drawing.Point(24, 42)
$lblS.Size = New-Object System.Drawing.Size(500, 20)
$cab.Controls.Add($lblS)

$lblModo = New-Object System.Windows.Forms.Label
$lblModo.Font = $F_Cabec
$lblModo.TextAlign = 'MiddleRight'
$lblModo.Location = New-Object System.Drawing.Point(560, 25)
$lblModo.Size = New-Object System.Drawing.Size(370, 24)
$cab.Controls.Add($lblModo)

# ------------------------------------------------------ Card estado
$cardE = New-Object System.Windows.Forms.Panel
$cardE.Size = New-Object System.Drawing.Size(300, 400)
$cardE.Location = New-Object System.Drawing.Point(20, 90)
$cardE.BackColor = $C_Branco
$cardE.BorderStyle = 'FixedSingle'
$form.Controls.Add($cardE)

$lblEc = New-Object System.Windows.Forms.Label
$lblEc.Text = 'ESTADO DO SISTEMA'
$lblEc.Font = $F_Cabec
$lblEc.ForeColor = $C_Escuro
$lblEc.Location = New-Object System.Drawing.Point(14, 12)
$lblEc.Size = New-Object System.Drawing.Size(270, 20)
$cardE.Controls.Add($lblEc)

$txtEstado = New-Object System.Windows.Forms.Label
$txtEstado.Font = $F_Texto
$txtEstado.ForeColor = [System.Drawing.Color]::FromArgb(55,65,81)
$txtEstado.Location = New-Object System.Drawing.Point(14, 38)
$txtEstado.Size = New-Object System.Drawing.Size(272, 352)
$cardE.Controls.Add($txtEstado)

# ------------------------------------------------------ Card imagens
$cardC = New-Object System.Windows.Forms.Panel
$cardC.Size = New-Object System.Drawing.Size(580, 400)
$cardC.Location = New-Object System.Drawing.Point(340, 90)
$cardC.BackColor = $C_Branco
$cardC.BorderStyle = 'FixedSingle'
$form.Controls.Add($cardC)

$lblCc = New-Object System.Windows.Forms.Label
$lblCc.Text = 'IMAGENS DISPONIVEIS'
$lblCc.Font = $F_Cabec
$lblCc.ForeColor = $C_Escuro
$lblCc.Location = New-Object System.Drawing.Point(14, 12)
$lblCc.Size = New-Object System.Drawing.Size(300, 20)
$cardC.Controls.Add($lblCc)

$btnAtualizar = New-Object System.Windows.Forms.Button
$btnAtualizar.Text = 'Atualizar lista'
$btnAtualizar.Font = $F_Texto
$btnAtualizar.Location = New-Object System.Drawing.Point(455, 9)
$btnAtualizar.Size = New-Object System.Drawing.Size(107, 26)
$btnAtualizar.BackColor = [System.Drawing.Color]::FromArgb(229,231,235)
$btnAtualizar.FlatStyle = 'Flat'
$btnAtualizar.Cursor = 'Hand'
$cardC.Controls.Add($btnAtualizar)

$lista = New-Object System.Windows.Forms.ListBox
$lista.Font = New-Object System.Drawing.Font('Segoe UI', 11)
$lista.Location = New-Object System.Drawing.Point(14, 44)
$lista.Size = New-Object System.Drawing.Size(548, 240)
$lista.BorderStyle = 'FixedSingle'
$cardC.Controls.Add($lista)

$txtDesc = New-Object System.Windows.Forms.Label
$txtDesc.Font = $F_Texto
$txtDesc.ForeColor = $C_Cinza
$txtDesc.Location = New-Object System.Drawing.Point(14, 294)
$txtDesc.Size = New-Object System.Drawing.Size(548, 94)
$cardC.Controls.Add($txtDesc)

# ------------------------------------------------------ Botoes
function Novo-Botao {
    param($Texto, $X, $Y, $L, $A, $Cor)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Texto
    $b.Font = $F_Botao
    $b.Location = New-Object System.Drawing.Point($X, $Y)
    $b.Size = New-Object System.Drawing.Size($L, $A)
    $b.BackColor = $Cor
    $b.ForeColor = $C_Branco
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.Cursor = 'Hand'
    $b.Tag = $Cor
    $form.Controls.Add($b)
    return $b
}

$btnImportar = Novo-Botao "1. Importar minha imagem"    20 510 218 56 $C_Roxo
$btnPreparar = Novo-Botao "2. Preparar ambiente"       248 510 218 56 $C_Azul
$btnTestar   = Novo-Botao "3. Testar (nao formata)"    476 510 218 56 $C_Verde
$btnFormatar = Novo-Botao "4. FORMATAR este PC"        704 510 216 56 $C_Vermelho

$btnReverter  = Novo-Botao 'Cancelar / Reverter'        20 580 220 40 $C_Cinza
$btnResultado = Novo-Botao 'Ver ultimo resultado'      250 580 220 40 $C_Cinza
$btnLimpar    = Novo-Botao 'Remover area de trabalho'  480 580 220 40 $C_Cinza
$btnLogs      = Novo-Botao 'Abrir registros'           710 580 210 40 $C_Cinza

$dica = New-Object System.Windows.Forms.Label
$dica.Font = $F_Texto
$dica.ForeColor = $C_Escuro
$dica.Location = New-Object System.Drawing.Point(22, 632)
$dica.Size = New-Object System.Drawing.Size(900, 40)
$form.Controls.Add($dica)

$barra = New-Object System.Windows.Forms.Label
$barra.Font = $F_Mini
$barra.ForeColor = $C_Cinza
$barra.Location = New-Object System.Drawing.Point(22, 678)
$barra.Size = New-Object System.Drawing.Size(900, 20)
$form.Controls.Add($barra)

# ============================================================ LOGICA

$Script:Itens = @()

function Ligar-Botao {
    param($Botao, [bool]$Ligado)
    $Botao.Enabled = $Ligado
    if ($Ligado) { $Botao.BackColor = $Botao.Tag } else { $Botao.BackColor = $C_Inativo }
}

function Carregar-Imagens {
    $lista.Items.Clear()
    $txtDesc.Text = ''
    $Script:Itens = @()

    foreach ($md in (Listar-Midias)) {
        if ($md.Edicoes -and @($md.Edicoes).Count -gt 0) {
            foreach ($e in @($md.Edicoes)) {
                $Script:Itens += [pscustomobject]@{
                    MidiaNome = $md.Nome
                    Indice    = $e.Indice
                    Rotulo    = $e.Nome
                    Arquivo   = $md.ImagemNome
                    Tamanho   = $md.Tamanho
                    Partes    = $md.Partes
                }
            }
        } else {
            $Script:Itens += [pscustomobject]@{
                MidiaNome = $md.Nome
                Indice    = 1
                Rotulo    = $md.ImagemNome
                Arquivo   = $md.ImagemNome
                Tamanho   = $md.Tamanho
                Partes    = $md.Partes
            }
        }
    }

    if ($Script:Itens.Count -eq 0) {
        [void]$lista.Items.Add('(nenhuma imagem baixada neste computador ainda)')
        $lista.Enabled = $false

        $site = Obter-UrlSite
        $txt  = "Esta lista mostra so as imagens que JA foram baixadas neste computador." +
                "`r`nComo esta e a primeira vez aqui, ela comeca vazia. Isso e normal." +
                "`r`n`r`nClique no botao roxo `"1. Importar minha imagem`"." +
                "`r`n`r`n  SIM  = baixar do site (imagem publicada no catalogo)" +
                "`r`n  NAO  = usar um arquivo .zip ou .iso deste computador"
        if ($site) { $txt += "`r`n`r`nSite configurado: $site" }
        else       { $txt += "`r`n`r`nAVISO: nenhum site configurado - so a opcao NAO vai funcionar." }

        $txtDesc.Text = $txt
        return
    }

    $lista.Enabled = $true
    foreach ($it in $Script:Itens) {
        [void]$lista.Items.Add("$($it.Rotulo)     -     $(Formatar-Tamanho $it.Tamanho)")
    }
}

function Atualizar-Estado {
    $e = Obter-EstadoSistema
    $temImagem = ($Script:Itens.Count -gt 0)

    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine("Equipamento")
    [void]$sb.AppendLine("  $($e.Fabricante)")
    [void]$sb.AppendLine("  $($e.Modelo)")
    [void]$sb.AppendLine("  Serie: $($e.Serie)")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("Inicializacao")
    [void]$sb.AppendLine("  Firmware...: $($e.Firmware)")
    [void]$sb.AppendLine("  Secure Boot: $($e.SecureBootTxt)")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("Recursos")
    [void]$sb.AppendLine("  Memoria....: $($e.RamGb) GB")
    [void]$sb.AppendLine("  Livre em C:: $($e.LivreGb) GB")
    [void]$sb.AppendLine("  Energia....: $($e.EnergiaTxt)")
    [void]$sb.AppendLine("")
    [void]$sb.AppendLine("Situacao")
    [void]$sb.AppendLine("  Imagem.....: " + $(if ($temImagem) { "$($Script:Itens.Count) disponivel(is)" } else { 'nenhuma' }))
    [void]$sb.AppendLine("  Ambiente...: " + $(if ($e.WinPEPronto) { "pronto ($($e.WinPEMb) MB)" } else { 'nao preparado' }))
    [void]$sb.AppendLine("  BitLocker..: " + $(if ($e.BitLocker) { 'LIGADO - bloqueia' } else { 'desligado' }))

    $st = Obter-AreaStaging
    if ($st) { [void]$sb.AppendLine("  Area disco.: $($st.DriveLetter): criada") }

    $txtEstado.Text = $sb.ToString()

    Ligar-Botao $btnImportar $true
    Ligar-Botao $btnPreparar $temImagem
    Ligar-Botao $btnTestar   ($e.WinPEPronto -and -not $e.BitLocker)
    Ligar-Botao $btnFormatar ($e.WinPEPronto -and -not $e.BitLocker -and $lista.SelectedIndex -ge 0)

    if ($e.BitLocker) {
        $lblModo.Text = 'BitLocker ligado - suspenda antes'
        $lblModo.ForeColor = [System.Drawing.Color]::FromArgb(248,113,113)
        $dica.Text = 'O BitLocker precisa ser suspenso. Abra o PowerShell como administrador e rode:' +
                     "`r`n    Suspend-BitLocker -MountPoint C: -RebootCount 2"
    } elseif (-not $temImagem) {
        $lblModo.Text = 'Comece pelo passo 1'
        $lblModo.ForeColor = [System.Drawing.Color]::FromArgb(250,204,21)
        $dica.Text = 'PASSO 1: clique no botao roxo e escolha o arquivo .zip da sua imagem do Windows.' +
                     "`r`nPode demorar ate 40 minutos. Deixe rodando."
    } elseif (-not $e.WinPEPronto) {
        $lblModo.Text = 'Falta preparar o ambiente'
        $lblModo.ForeColor = [System.Drawing.Color]::FromArgb(250,204,21)
        $dica.Text = 'PASSO 2: clique no botao azul. Leva de 5 a 15 minutos e so precisa ser feito uma vez.'
    } else {
        $lblModo.Text = 'Tudo pronto'
        $lblModo.ForeColor = [System.Drawing.Color]::FromArgb(74,222,128)
        $dica.Text = 'PASSO 3: clique no botao verde para testar sem apagar nada.' +
                     "`r`nSo use o botao vermelho depois que o teste funcionar."
    }

    $barra.Text = "Registros: $Global:PASTA_LOG    |    Dados: $Global:DADOS"
}

function Rodar-Acao {
    param([string]$Acao, [hashtable]$Extra = @{})

    $exec = Join-Path $PSScriptRoot 'executar.ps1'
    $argumentos = @('-NoProfile','-ExecutionPolicy','Bypass','-File', "`"$exec`"", '-Acao', $Acao)
    foreach ($k in $Extra.Keys) { $argumentos += @("-$k", "`"$($Extra[$k])`"") }

    $form.Enabled = $false
    try   { Start-Process powershell.exe -ArgumentList $argumentos -Wait }
    catch { [System.Windows.Forms.MessageBox]::Show("Nao consegui iniciar:`n$_",'Erro','OK','Error') | Out-Null }
    $form.Enabled = $true

    Carregar-Imagens
    Atualizar-Estado
}

# ------------------------------------------------------ Eventos

$lista.Add_SelectedIndexChanged({
    $i = $lista.SelectedIndex
    if ($i -ge 0 -and $i -lt $Script:Itens.Count) {
        $it = $Script:Itens[$i]
        $div = ''
        if ($it.Partes -gt 1) { $div = "   (dividida em $($it.Partes) partes)" }
        $txtDesc.Text = "Edicao: $($it.Rotulo)`r`n" +
                        "Indice: $($it.Indice)$div`r`n" +
                        "Arquivo: $($it.Arquivo)`r`n" +
                        "Origem: $($it.MidiaNome)"
    }
    Atualizar-Estado
})

$btnAtualizar.Add_Click({ Carregar-Imagens; Atualizar-Estado })

$btnImportar.Add_Click({
    $site = Obter-UrlSite

    $msg = "De onde vem a imagem do Windows?" +
           "`n`n  SIM  = baixar de um endereco (servidor da rede ou site)" +
           "`n  NAO  = escolher um arquivo .zip ou .iso deste computador"

    $r = [System.Windows.Forms.MessageBox]::Show($msg, 'Importar imagem', 'YesNoCancel', 'Question')
    if ($r -eq 'Cancel') { return }

    if ($r -eq 'Yes') {
        # Sempre mostra o endereco para conferir/trocar. O que estiver salvo
        # vem preenchido, entao no uso normal e so dar OK.
        $sugestao = if ($site) { $site } else { 'http://' }

        $site = [Microsoft.VisualBasic.Interaction]::InputBox(
            ("De onde baixar a imagem?" +
             "`n`nServidor na rede:  http://192.168.0.10:8080" +
             "`nSite na internet:  https://myboot-win.netlify.app" +
             "`n`nConfira o endereco abaixo e corrija se precisar:"),
            'Endereco da imagem', $sugestao)

        $site = "$site".Trim()
        if ([string]::IsNullOrWhiteSpace($site) -or $site -eq 'http://' -or $site -eq 'https://') { return }

        # Guarda para vir preenchido da proxima vez neste computador
        try {
            Set-Content -Path (Join-Path $Global:RAIZ 'site.txt') -Value $site -Encoding ASCII -Force
        } catch { }

        Rodar-Acao 'baixar-midia' @{ UrlSite = $site }
        return
    }

    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = 'Escolha o .zip ou .iso da sua imagem do Windows'
    $dlg.Filter = 'Imagem do Windows (*.zip;*.iso)|*.zip;*.iso|Todos os arquivos (*.*)|*.*'
    if ($dlg.ShowDialog() -ne 'OK') { return }

    Rodar-Acao 'importar-midia' @{ Caminho = $dlg.FileName }
})

$btnPreparar.Add_Click({
    $r = [System.Windows.Forms.MessageBox]::Show(
        "Preparar o ambiente de formatacao.`n`nLeva de 5 a 15 minutos e so precisa ser feito uma vez.`n`nContinuar?",
        'Preparar ambiente', 'YesNo', 'Question')
    if ($r -eq 'Yes') { Rodar-Acao 'preparar-ambiente' }
})

$btnTestar.Add_Click({
    $r = [System.Windows.Forms.MessageBox]::Show(
        "TESTE SEGURO`n`nO computador vai reiniciar, carregar o ambiente, mostrar um diagnostico e voltar sozinho para o Windows.`n`nNENHUM DADO SERA APAGADO.`n`nContinuar?",
        'Testar', 'YesNo', 'Question')
    if ($r -eq 'Yes') { Rodar-Acao 'testar-boot' }
})

$btnFormatar.Add_Click({
    $i = $lista.SelectedIndex
    if ($i -lt 0 -or $i -ge $Script:Itens.Count) { return }
    $it = $Script:Itens[$i]

    $r = [System.Windows.Forms.MessageBox]::Show(
        "ATENCAO - OPERACAO DESTRUTIVA`n`nImagem: $($it.Rotulo)`n`nTODOS OS DADOS deste computador serao APAGADOS.`n`nConfirme antes:`n  - Backup do cliente ja foi feito`n  - Este e o computador certo`n  - O carregador esta conectado`n`nTem certeza absoluta?",
        'FORMATAR COMPUTADOR', 'YesNo', 'Warning', 'Button2')
    if ($r -ne 'Yes') { return }

    $r2 = [System.Windows.Forms.MessageBox]::Show(
        "AVISO TECNICO`n`nO modo de formatacao real ainda nao foi validado no seu hardware.`n`nUse primeiro o botao verde (Testar) em um equipamento descartavel.`n`nProsseguir mesmo assim?",
        'Confirmacao final', 'YesNo', 'Warning', 'Button2')
    if ($r2 -ne 'Yes') { return }

    Rodar-Acao 'formatar' @{ MidiaNome = $it.MidiaNome; Indice = $it.Indice }
})

$btnReverter.Add_Click({ Rodar-Acao 'desarmar' })
$btnLimpar.Add_Click({ Rodar-Acao 'limpar-staging' })
$btnLogs.Add_Click({ Start-Process explorer.exe $Global:PASTA_LOG })

$btnResultado.Add_Click({
    $r = Obter-ResultadoWinPE
    if (-not $r) {
        [System.Windows.Forms.MessageBox]::Show(
            "Nenhum resultado encontrado ainda.`n`nFaca o teste (botao verde) primeiro.",
            'Sem resultados','OK','Information') | Out-Null
        return
    }

    $sucesso = ($r['SUCESSO'] -eq 'SIM')
    $icone = if ($sucesso) { 'Information' } else { 'Error' }

    $msg = "Modo........: $($r['MODO'])`r`n" +
           "Resultado...: $(if ($sucesso) { 'SUCESSO' } else { 'FALHOU' })`r`n`r`n" +
           "$($r['RESUMO'])`r`n`r`n" +
           "Firmware....: $($r['FIRMWARE'])`r`n" +
           "Secure Boot.: $($r['SECUREBOOT'])`r`n" +
           "Quando......: $($r['_Quando'])"

    [System.Windows.Forms.MessageBox]::Show($msg, 'Ultimo resultado', 'OK', $icone) | Out-Null
})

# ------------------------------------------------------ Inicio

Carregar-Imagens
Atualizar-Estado
[void]$form.ShowDialog()
