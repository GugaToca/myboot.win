<#
    diagnostico.ps1 - Coleta informacoes da maquina para analise.
    NAO altera nada.
#>

$lib = Join-Path $PSScriptRoot 'lib'
. (Join-Path $lib 'comum.ps1')

$L = New-Object System.Collections.Generic.List[string]
function D($t = '', $cor = 'Gray') { Write-Host $t -ForegroundColor $cor; $L.Add($t) }
function T($t) { D ''; D ('--- ' + $t + ' ' + ('-' * [Math]::Max(0, 56 - $t.Length))) Cyan }

D ('=' * 64) Cyan
D '  DIAGNOSTICO - SISTEMA DE FORMATACAO' Cyan
D ('=' * 64) Cyan
D "Gerado em: $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')"

# ---------------------------------------------------------- Sistema
T 'SISTEMA OPERACIONAL'
$os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
D "Nome .........: $($os.Caption)"
D "Versao .......: $($os.Version)  (build $($os.BuildNumber))"
D "Arquitetura ..: $($os.OSArchitecture)"
D "PowerShell ...: $($PSVersionTable.PSVersion)"
D "Administrador : $(Testar-Admin)"

# ---------------------------------------------------------- Maquina
T 'EQUIPAMENTO'
$cs  = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
$bio = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
D "Fabricante ...: $($cs.Manufacturer)"
D "Modelo .......: $($cs.Model)"
D "Serie ........: $($bio.SerialNumber)"
D "BIOS versao ..: $($bio.SMBIOSBIOSVersion)"
D "RAM ..........: $([math]::Round($cs.TotalPhysicalMemory/1GB,1)) GB"

# ---------------------------------------------------------- Firmware
T 'FIRMWARE (a parte que deu erro)'
$fw = Obter-Firmware
D "Modo detectado: $($fw.Modo)"
D "Detectado via : $($fw.Via)"
D "Carregador ...: $($fw.Loader)"
D "Secure Boot ..: $($fw.SecureBootTxt)"
D ""
D "Resposta de cada metodo:"
D "  $($fw.Tentativas)"
D ""
D "Valores brutos:"
try {
    $r = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control' -Name PEFirmwareType -ErrorAction Stop
    D "  registro PEFirmwareType = $($r.PEFirmwareType)"
} catch { D "  registro PEFirmwareType = NAO EXISTE" }
D "  variavel firmware_type  = '$env:firmware_type'"

# ---------------------------------------------------------- Boot
T 'CONFIGURACAO DE INICIALIZACAO'
try {
    $b = (& bcdedit.exe /enum '{current}' 2>&1 | Out-String)
    foreach ($linha in ($b -split "`r?`n")) { if ($linha.Trim()) { D "  $linha" } }
} catch { D "  bcdedit falhou: $_" }

# ---------------------------------------------------------- Discos
T 'DISCOS E PARTICOES'
try {
    foreach ($d in (Get-Disk -ErrorAction Stop | Sort-Object Number)) {
        D ("Disco {0}: {1} | {2} GB | {3} | {4}" -f $d.Number, $d.FriendlyName,
           [math]::Round($d.Size/1GB,1), $d.BusType, $d.PartitionStyle)
        foreach ($p in (Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue)) {
            $letra = if ($p.DriveLetter) { "$($p.DriveLetter):" } else { '  ' }
            D ("   part {0}  {1}  {2,8} GB  tipo={3}" -f $p.PartitionNumber, $letra,
               [math]::Round($p.Size/1GB,1), $p.GptType)
        }
    }
} catch { D "  Falha ao listar discos: $_" }

# ---------------------------------------------------------- Volumes
T 'ESPACO EM DISCO'
foreach ($v in (Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.DriveLetter })) {
    D ("{0}:  {1,7} GB livres de {2,7} GB   {3}" -f $v.DriveLetter,
       [math]::Round($v.SizeRemaining/1GB,1), [math]::Round($v.Size/1GB,1), $v.FileSystemLabel)
}

# ---------------------------------------------------------- BitLocker
T 'BITLOCKER'
try {
    foreach ($b in (Get-BitLockerVolume -ErrorAction Stop)) {
        D "$($b.MountPoint)  protecao=$($b.ProtectionStatus)  $($b.VolumeStatus)"
    }
} catch { D "  Nao disponivel nesta edicao do Windows" }

# ---------------------------------------------------------- Sistema
T 'ESTADO DO SISTEMA DE FORMATACAO'
$e = Obter-EstadoSistema
D "Ambiente preparado: $($e.WinPEPronto)"
if ($e.WinPEPronto) { D "Tamanho do ambiente: $($e.WinPEMb) MB" }
D "Windows ADK ......: $($e.AdkOk)"

$mds = @()
try { . (Join-Path $lib 'midia.ps1'); $mds = @(Listar-Midias) } catch {}
D "Imagens importadas: $($mds.Count)"
foreach ($m in $mds) { D "  - $($m.Nome)  ($($m.ImagemNome), $($m.Partes) parte(s))" }

# ---------------------------------------------------------- Salvar
$arq = Join-Path ([Environment]::GetFolderPath('Desktop')) 'diagnostico-formatacao.txt'
try {
    $L | Out-File $arq -Encoding UTF8 -Force
    Write-Host ''
    Write-Host ('=' * 64) -ForegroundColor Green
    Write-Host '  ARQUIVO SALVO NA SUA AREA DE TRABALHO:' -ForegroundColor Green
    Write-Host "  diagnostico-formatacao.txt" -ForegroundColor Green
    Write-Host ''
    Write-Host '  Envie esse arquivo para analise.' -ForegroundColor Green
    Write-Host ('=' * 64) -ForegroundColor Green
} catch {
    Write-Host ''
    Write-Host "  Nao consegui salvar o arquivo: $_" -ForegroundColor Red
    Write-Host '  Tire uma foto da tela.' -ForegroundColor Yellow
}
