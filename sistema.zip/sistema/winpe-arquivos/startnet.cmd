@echo off
rem ===================================================================
rem  Sistema de Formatacao - arranque do ambiente WinPE
rem ===================================================================

wpeinit

rem Espera os drivers de armazenamento aparecerem
ping -n 6 127.0.0.1 >nul

rem O deploy e em CMD de proposito: funciona em qualquer WinPE,
rem inclusive nos que nao tem PowerShell instalado.
call X:\Windows\System32\deploy.cmd

rem Se o deploy retornar, deixa um prompt aberto para investigar
echo.
echo   O processo terminou. Digite  wpeutil reboot  para reiniciar.
echo.
