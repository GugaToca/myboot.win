@echo off
setlocal EnableDelayedExpansion

rem ===================================================================
rem  deploy.cmd - roda DENTRO do ambiente WinPE
rem
rem  Escrito em CMD de proposito: diskpart e dism existem em QUALQUER
rem  WinPE. PowerShell nao existe em todos.
rem
rem  Modos:
rem    TESTE = so diagnostico, nao toca em disco   (padrao)
rem    REAL  = formata a particao do Windows e grava a imagem
rem ===================================================================

color 1F
mode con: cols=100 lines=40
cls

echo.
echo   ================================================================
echo                     SISTEMA DE FORMATACAO
echo   ================================================================
echo.

rem ---------------------------------------------------------------
rem  1. LOCALIZAR A AREA DE TRABALHO
rem ---------------------------------------------------------------
set BASE=
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist %%D:\DEPLOY\MARCADOR.txt set BASE=%%D:\DEPLOY
)

if "%BASE%"=="" (
    echo   [ERRO] Area de trabalho nao encontrada em nenhuma unidade.
    echo.
    echo   O sistema nao pode continuar.
    goto :FIM_ERRO
)

echo   Area de trabalho ....: %BASE%

rem ---------------------------------------------------------------
rem  2. LER A TAREFA
rem ---------------------------------------------------------------
set MODO=TESTE
set IMAGEM=
set INDICE=1
set NOME=
set DISCO=0
set PARTESP=

if exist "%BASE%\tarefa.txt" (
    for /f "usebackq tokens=1,* delims==" %%A in ("%BASE%\tarefa.txt") do (
        if /i "%%A"=="MODO"    set MODO=%%B
        if /i "%%A"=="IMAGEM"  set IMAGEM=%%B
        if /i "%%A"=="INDICE"  set INDICE=%%B
        if /i "%%A"=="NOME"    set NOME=%%B
        if /i "%%A"=="DISCO"   set DISCO=%%B
        if /i "%%A"=="PARTESP" set PARTESP=%%B
    )
)

rem Trava de seguranca: qualquer valor estranho vira TESTE
if /i not "%MODO%"=="REAL" set MODO=TESTE

echo   Modo de operacao ....: %MODO%
if /i "%MODO%"=="TESTE" echo   ^(modo seguro - nenhum disco sera modificado^)
echo.

rem ---------------------------------------------------------------
rem  3. DIAGNOSTICO
rem ---------------------------------------------------------------
echo   ----------------------------------------------------------------
echo    DIAGNOSTICO DO EQUIPAMENTO
echo   ----------------------------------------------------------------

set FIRMWARE=BIOS Legacy
if exist %SystemDrive%\Windows\System32\wpeutil.exe (
    reg query "HKLM\SYSTEM\CurrentControlSet\Control" /v PEFirmwareType 2>nul | find "0x2" >nul
    if not errorlevel 1 set FIRMWARE=UEFI
)

set SECUREBOOT=Desligado
reg query "HKLM\SYSTEM\CurrentControlSet\Control\SecureBoot\State" /v UEFISecureBootEnabled 2>nul | find "0x1" >nul
if not errorlevel 1 set SECUREBOOT=LIGADO

echo    Firmware ..........: %FIRMWARE%
echo    Secure Boot .......: %SECUREBOOT%
echo.

if "%SECUREBOOT%"=="LIGADO" (
    echo    ^>^>^> O ambiente carregou com Secure Boot LIGADO.
    echo    ^>^>^> A arquitetura funciona neste equipamento.
) else (
    echo    ^>^>^> Carregou com Secure Boot desligado ou em modo Legacy.
)
echo.

echo   ----------------------------------------------------------------
echo    DISCOS DETECTADOS
echo   ----------------------------------------------------------------
(
 echo list disk
) > X:\lsd.txt
diskpart /s X:\lsd.txt
echo.

echo   ----------------------------------------------------------------
echo    VOLUMES
echo   ----------------------------------------------------------------
(
 echo list volume
) > X:\lsv.txt
diskpart /s X:\lsv.txt
echo.

rem ---------------------------------------------------------------
rem  4. MODO TESTE - grava resultado e termina
rem ---------------------------------------------------------------
if /i "%MODO%"=="TESTE" (
    (
      echo MODO=TESTE
      echo SUCESSO=SIM
      echo FIRMWARE=%FIRMWARE%
      echo SECUREBOOT=%SECUREBOOT%
      echo RESUMO=Teste de inicializacao concluido. Nenhum disco modificado.
    ) > "%BASE%\resultado.txt"

    echo   ================================================================
    echo    TESTE CONCLUIDO COM SUCESSO
    echo.
    echo    Nenhum disco foi modificado.
    echo   ================================================================
    goto :FIM_OK
)

rem ---------------------------------------------------------------
rem  5. MODO REAL - formatacao
rem ---------------------------------------------------------------
echo   ================================================================
echo    GRAVANDO O WINDOWS
echo   ================================================================
echo.
echo    Imagem: %NOME%
echo.

rem --- 5.1 Localizar a particao alvo (a que tem o marcador do sistema)
set ALVO=
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if exist %%D:\ALVO_FORMATACAO.txt set ALVO=%%D:
)

if "%ALVO%"=="" (
    echo   [ERRO] Nao encontrei a particao do Windows a ser formatada.
    echo   O marcador ALVO_FORMATACAO.txt nao esta em nenhum volume.
    goto :FIM_ERRO
)
echo    Particao a formatar .: %ALVO%

rem --- 5.2 Conferir se a imagem existe
if not exist "%BASE%\%IMAGEM%" (
    echo   [ERRO] Imagem nao encontrada: %BASE%\%IMAGEM%
    goto :FIM_ERRO
)

rem --- 5.3 Dar letra S: para a particao de sistema (EFI)
if "%FIRMWARE%"=="UEFI" (
    if not "%PARTESP%"=="" (
        (
          echo select disk %DISCO%
          echo select partition %PARTESP%
          echo assign letter=S
        ) > X:\esp.txt
        diskpart /s X:\esp.txt >nul 2>&1
        echo    Particao de sistema .: S:
    )
)

rem --- 5.4 Formatar a particao do Windows
echo.
echo    Formatando %ALVO% ...
format %ALVO% /fs:ntfs /q /y /v:Windows >nul 2>&1
if errorlevel 1 (
    echo   [ERRO] Falha ao formatar %ALVO%
    goto :FIM_ERRO
)
echo    Formatacao concluida.
echo.

rem --- 5.5 Aplicar a imagem
echo    Gravando o Windows. Isto leva de 5 a 20 minutos.
echo    NAO DESLIGUE O EQUIPAMENTO.
echo.

echo %IMAGEM% | find /i ".swm" >nul
if not errorlevel 1 (
    rem Imagem dividida em varias partes
    dism /Apply-Image /ImageFile:"%BASE%\%IMAGEM%" /SWMFile:"%BASE%\*.swm" /Index:%INDICE% /ApplyDir:%ALVO%\ /LogPath:"%BASE%\dism.log"
) else (
    dism /Apply-Image /ImageFile:"%BASE%\%IMAGEM%" /Index:%INDICE% /ApplyDir:%ALVO%\ /LogPath:"%BASE%\dism.log"
)

if errorlevel 1 (
    echo.
    echo   [ERRO] A gravacao falhou. Detalhes em %BASE%\dism.log
    (
      echo MODO=REAL
      echo SUCESSO=NAO
      echo RESUMO=Falha na gravacao da imagem ^(dism^). Veja dism.log
    ) > "%BASE%\resultado.txt"
    goto :FIM_ERRO
)
echo.
echo    Windows gravado com sucesso.

rem --- 5.6 Drivers adicionais
if exist "%BASE%\drivers" (
    echo    Instalando drivers adicionais...
    dism /Image:%ALVO%\ /Add-Driver /Driver:"%BASE%\drivers" /Recurse /ForceUnsigned >nul 2>&1
    echo    Drivers instalados.
)

rem --- 5.7 Configuracao automatica
if exist "%BASE%\unattend.xml" (
    if not exist %ALVO%\Windows\Panther mkdir %ALVO%\Windows\Panther
    copy /y "%BASE%\unattend.xml" %ALVO%\Windows\Panther\unattend.xml >nul
    echo    Configuracao automatica aplicada.
)

rem --- 5.8 Criar o carregador de inicializacao
echo    Criando o carregador de inicializacao...
if "%FIRMWARE%"=="UEFI" (
    bcdboot %ALVO%\Windows /s S: /f UEFI
) else (
    bcdboot %ALVO%\Windows /s %ALVO% /f BIOS
)

if errorlevel 1 (
    echo   [ERRO] Falha ao criar o carregador de inicializacao.
    (
      echo MODO=REAL
      echo SUCESSO=NAO
      echo RESUMO=Imagem gravada mas o bcdboot falhou.
    ) > "%BASE%\resultado.txt"
    goto :FIM_ERRO
)

(
  echo MODO=REAL
  echo SUCESSO=SIM
  echo FIRMWARE=%FIRMWARE%
  echo SECUREBOOT=%SECUREBOOT%
  echo RESUMO=Windows gravado com sucesso: %NOME%
) > "%BASE%\resultado.txt"

echo.
echo   ================================================================
echo    FORMATACAO CONCLUIDA COM SUCESSO
echo.
echo    O equipamento vai reiniciar no Windows novo.
echo   ================================================================

goto :FIM_OK

rem ---------------------------------------------------------------
:FIM_ERRO
echo.
echo   ================================================================
echo    O PROCESSO FOI INTERROMPIDO
echo.
echo    Leia a mensagem acima. Tire uma foto desta tela.
echo   ================================================================
echo.
echo    Digite  wpeutil reboot  para voltar ao Windows.
echo.
cmd /k
exit /b 1

rem ---------------------------------------------------------------
:FIM_OK
echo.
echo    Reiniciando em 60 segundos. Pressione uma tecla para ir agora.
timeout /t 60
wpeutil reboot
exit /b 0
